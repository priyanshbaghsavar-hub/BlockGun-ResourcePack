# BlockGun Resource Pack

A complete, mod-free resource pack for the **BlockGun** Paper plugin: every one of
the 1,012 registered blocks gets its own **3D handheld drill** and its own **3D
gun** — 2,024 custom models, and **every drill and every gun has its own texture
file** in this pack.

* The drill is a genuine custom model: boxy motor housing, chuck collar,
  protruding steel bit, angled pistol grip, trigger, battery pack and side vents.
  It is **not** a recoloured shovel/pickaxe/axe/hoe.
* The gun is a fictional firearm silhouette (receiver, barrel + muzzle, stock,
  grip, magazine, sights) — not a bow, crossbow or any vanilla tool.
* Same drill family and gun family for every block; only the materials/colours
  change per block (dirt = brown, stone = gray, gold = golden, diamond = cyan,
  emerald = green, netherite = near-black with purple-tinted metal, copper =
  copper, oxidized copper = verdigris, …).
* Block colours were averaged from the **real vanilla block textures** of
  Minecraft 1.21.11.

## Contents

```
pack.mcmeta                          pack_format 69, accepted range 69-75 (1.21.9-1.21.11)
pack.png / preview.png               icon and renders
assets/blockgun/textures/item/
    drill/<block>.png                1,012 drill textures (one per block)
    gun/<block>.png                  1,012 gun textures (one per block)
    steel.png                        shared drill-bit metal
assets/blockgun/models/item/
    drill_template.json              the 18-box drill geometry + display transforms
    gun_template.json                the 18-box gun geometry + display transforms
    <block>_drill.json               1,012 tiny models (parent + texture pointer)
    <block>_gun.json                 1,012 tiny models
assets/minecraft/models/item/
    iron_shovel.json, crossbow.json  ONLY additive custom_model_data overrides
```

### Texture layout (32×32 per item, easy to edit)

```
+----------------+----------------+
|                |  metal region  |   <- chuck / barrel / hardware
|  body region   |----------------|
|  (block colour)|  dark region   |   <- grip / battery / trigger / magazine
+----------------+----------------+
```

Open any `drill/<block>.png` or `gun/<block>.png` in an image editor, repaint a
region, save — the model updates. The model samples each region through fixed UV
quadrants, and `steel.png` supplies the drill bit.

### Ammo

BlockGun's ammo is the gun's **magazine**, shown on the action bar (`AMMO: 9/9`)
and refilled by reloading — it is not a physical item, so there is no ammo item
texture to ship. Everything that exists as an item (2,024 of them) has a texture
in this pack. If you later add physical ammo items to the plugin, drop their
textures into `assets/blockgun/textures/item/ammo/` and add model files the same
way as above.

## How the wiring works (CustomModelData)

The plugin stamps an integer CustomModelData onto each item; the pack maps those
integers to the custom models through **additive** `custom_model_data`
predicates:

| base item   | CMD range        | models                        |
|-------------|------------------|-------------------------------|
| IRON_SHOVEL | 10001 - 11012    | `blockgun:item/<block>_drill` |
| CROSSBOW    | 20001 - 21012    | `blockgun:item/<block>_gun`   |

`DIRT` → drill CMD **10315** / gun **20315**; `NETHERITE_BLOCK` → **10557** /
**20557**. The exact per-block mapping ships as `blocks-models.yml`.

**Vanilla tools are untouched.** The two overridden files keep their original
parent, textures and display; the `overrides` arrays are purely additive, so a
normal iron shovel or crossbow (no CustomModelData) renders exactly as vanilla.
No other vanilla item model file is touched.

## Server-side install (required for the models to appear)

1. Copy `blocks-models.yml` (next to this pack in the download) into
   `plugins/BlockGun/` on the server.
2. In `plugins/BlockGun/config.yml` set:
   ```yaml
   settings:
     additional-configs: [blocks-models.yml]
   ```
3. Run `/blockgun reload`. Every drill/gun now carries the CustomModelData the
   pack expects, on IRON_SHOVEL / CROSSBOW base items.

## Client-side install

Drop `BlockGun-ResourcePack.zip` **unextracted** into `.minecraft/resourcepacks/`
and enable it in Options → Resource Packs, or distribute it via
`resource-pack=` in `server.properties`. No Fabric, Forge, OptiFine or any
client mod is needed.

## Adding / editing blocks later

1. On the server: `/blockgun generate` → updated `blocks-generated.yml`.
2. Regenerate with `packgen/generate.py` (project workspace) — it re-reads the
   block list, re-averages colours, rewrites textures, models, overrides and
   `blocks-models.yml` in one run.
3. Redistribute pack + mapping, `/blockgun reload`.

## Performance

Each model is 18 axis-aligned boxes (108 faces), the same budget as many vanilla
3D item models; textures are 32×32, so the whole pack zips to a few MB.
